## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(nectar)

## ----auth, eval = FALSE-------------------------------------------------------
# req <- req_prepare(
#   "https://api.crossref.org/works",
#   query = list(
#     rows = 10, cursor = "*", select = c("publisher", "DOI"), .multi = "comma"
#   ),
#   auth = auth_api_key("mailto", api_key = "your@email.com", location = "query")
# )

## ----auth-remove, eval = FALSE------------------------------------------------
# req <- req_auth_api_key(
#   req, # From above, with "your@email.com" attached as the key.
#   parameter_name = "mailto",
#   api_key = NULL,
#   location = "query"
# )

## ----tidy, eval = FALSE-------------------------------------------------------
# req <- req_prepare(
#   "https://api.crossref.org/works",
#   query = list(
#     rows = 10, cursor = "*", select = c("publisher", "DOI"), .multi = "comma"
#   ),
#   tidy_fn = resp_tidy_json,
#   tidy_args = list(subset_path = c("message", "items"))
# )

## ----paginate, eval = FALSE---------------------------------------------------
# iterate_xref <- iterate_with_json_cursor(
#   param_name = "cursor",
#   next_cursor_path = c("message", "next-cursor")
# )

## ----prepare-full, eval = FALSE-----------------------------------------------
# req <- req_prepare(
#   "https://api.crossref.org/works",
#   query = list(
#     rows = 10, cursor = "*", select = c("publisher", "DOI"), .multi = "comma"
#   ),
#   tidy_fn = resp_tidy_json,
#   tidy_args = list(subset_path = c("message", "items")),
#   pagination_fn = iterate_xref
# )

## ----perform, eval = FALSE----------------------------------------------------
# resps <- req_perform_opinionated(req, max_reqs = 2)

## ----parse, eval = FALSE------------------------------------------------------
# result <- resp_parse(resps)
# result

## ----pipeline, eval = FALSE---------------------------------------------------
# result <- req_prepare(
#   "https://api.crossref.org/works",
#   query = list(
#     rows = 10, cursor = "*", select = c("publisher", "DOI"), .multi = "comma"
#   ),
#   tidy_fn = resp_tidy_json,
#   tidy_args = list(subset_path = c("message", "items")),
#   pagination_fn = iterate_with_json_cursor(
#     param_name = "cursor",
#     next_cursor_path = c("message", "next-cursor")
#   )
# ) |>
#   req_perform_opinionated(max_reqs = 3) |>
#   resp_parse()
# 
# result
# 
# #> # A tibble: 30 × 2
# #>    publisher                         DOI
# #>    <chr>                             <chr>
# #>  1 Springer Fachmedien Wiesbaden     10.1007/978-3-658-17671-6_18-1
# #>  2 Springer International Publishing 10.1007/978-3-031-23161-2_300726
# #>  3 Elsevier                          10.1016/b978-0-08-102696-0.00020-8
# #>  4 Springer International Publishing 10.1007/978-3-031-28170-9_6
# #>  5 Springer Nature Singapore         10.1007/978-981-16-8679-5_306
# #>  6 Springer Singapore                10.1007/978-981-15-1636-8_42
# #>  7 Springer Berlin Heidelberg        10.1007/978-3-642-33832-8_41
# #>  8 Springer Nature Switzerland       10.1007/978-3-031-72371-1_11
# #>  9 Springer International Publishing 10.1007/978-3-319-18938-3
# #> 10 Springer International Publishing 10.1007/978-3-319-19932-0_5
# #> # i 20 more rows
# #> # i Use `print(n = ...)` to see more rows

## ----package-example, eval = FALSE--------------------------------------------
# # R/works.R  (inside a hypothetical "crossref" package)
# works <- function(
#   rows = 20,
#   select = NULL,
#   mailto = NULL
# ) {
#   req_prepare(
#     "https://api.crossref.org/works",
#     query = list(rows = rows, cursor = "*", select = select),
#     auth = auth_api_key("mailto", api_key = mailto, location = "query"),
#     tidy_fn = resp_tidy_json,
#     tidy_args = list(subset_path = c("message", "items")),
#     pagination_fn = iterate_with_json_cursor(
#       param_name = "cursor",
#       next_cursor_path = c("message", "next-cursor")
#     )
#   ) |>
#     req_perform_opinionated() |>
#     resp_parse()
# }

