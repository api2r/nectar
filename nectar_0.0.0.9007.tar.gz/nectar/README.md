
<!-- README.md is generated from README.Rmd. Please edit that file -->

# nectar <a href="https://nectar.api2r.org"><img src="man/figures/logo.svg" align="right" height="278" /></a>

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![CRAN
status](https://www.r-pkg.org/badges/version/nectar)](https://CRAN.R-project.org/package=nectar)
[![Codecov test
coverage](https://codecov.io/gh/api2r/nectar/graph/badge.svg)](https://app.codecov.io/gh/api2r/nectar)
[![R-CMD-check](https://github.com/api2r/nectar/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/api2r/nectar/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

An opinionated framework for use within api-wrapping R packages.

## Installation

You can install the development version of nectar from
[GitHub](https://github.com/) with:

``` r
# install.packages("pak")
pak::pak("api2r/nectar")
```

## Usage

nectar provides an opinionated framework for building R packages that
wrap web APIs. The three core functions compose into a natural pipeline:

1.  Prepare a request (attach auth, pagination, and tidy functions)

``` r
req <- req_prepare(
  "https://api.crossref.org/works",
  query = list(
    rows = 10, cursor = "*", select = c("publisher", "DOI"), .multi = "comma"
  ),
  tidy_fn = resp_tidy_json,
  tidy_args = list(subset_path = c("message", "items")),
  pagination_fn = iterate_with_json_cursor(
    param_name = "cursor",
    next_cursor_path = c("message", "next-cursor")
  )
)
```

2.  Perform the request (handles pagination and retries automatically)

``` r
resps <- req_perform_opinionated(req, max_reqs = 2)
```

3.  Parse all responses into a single tibble

``` r
result <- resp_parse(resps)
result
```

See `vignette("nectar")` for a full walk-through.

## Code of Conduct

Please note that the nectar project is released with a [Contributor Code
of Conduct](https://nectar.api2r.org/CODE_OF_CONDUCT.html). By
contributing to this project, you agree to abide by its terms.
