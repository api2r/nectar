test_that("resp_body_auto works for json (#40)", {
  local_mocked_bindings(
    resp_body_json = function(resp) "json",
    .package = "httr2"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "application/json"))
  expect_identical(resp_body_auto(resp), "json")
})

test_that("resp_body_auto works for xml (#40)", {
  local_mocked_bindings(
    resp_body_xml = function(resp) "xml",
    .package = "httr2"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "application/xml"))
  expect_identical(resp_body_auto(resp), "xml")
  resp <- httr2::response(headers = list(`Content-Type` = "text/xml"))
  expect_identical(resp_body_auto(resp), "xml")
})

test_that("resp_body_auto works for html (#40)", {
  local_mocked_bindings(
    resp_body_html = function(resp) "html",
    .package = "httr2"
  )
  resp <- httr2::response(
    headers = list(`Content-Type` = "application/xhtml+xml")
  )
  expect_identical(resp_body_auto(resp), "html")
  resp <- httr2::response(headers = list(`Content-Type` = "text/html"))
  expect_identical(resp_body_auto(resp), "html")
})

test_that("resp_body_auto works for svg (#40)", {
  local_mocked_bindings(
    resp_body_string = function(resp) "string",
    .package = "httr2"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "image/svg+xml"))
  expect_identical(resp_body_auto(resp), "string")
})

test_that("resp_body_auto works for csv (#40)", {
  local_mocked_bindings(
    resp_body_csv = function(resp) "csv"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "text/csv"))
  expect_identical(resp_body_auto(resp), "csv")
})

test_that("resp_body_auto works for tsv (#40)", {
  local_mocked_bindings(
    resp_body_tsv = function(resp) "tsv"
  )
  resp <- httr2::response(
    headers = list(`Content-Type` = "text/tab-separated-values")
  )
  expect_identical(resp_body_auto(resp), "tsv")
})

test_that("resp_body_auto works for json subtypes (#40)", {
  local_mocked_bindings(
    resp_body_json = function(resp) "json",
    .package = "httr2"
  )
  resp <- httr2::response(
    headers = list(`Content-Type` = "application/vnd.api+json")
  )
  expect_identical(resp_body_auto(resp), "json")
})

test_that("resp_body_auto works for other strings (#40)", {
  local_mocked_bindings(
    resp_body_string = function(resp) "string",
    .package = "httr2"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "text/weird"))
  expect_identical(resp_body_auto(resp), "string")
})

test_that("resp_body_auto works for other things (#40)", {
  local_mocked_bindings(
    resp_body_raw = function(resp) "raw",
    .package = "httr2"
  )
  resp <- httr2::response(headers = list(`Content-Type` = "weird/thing"))
  expect_identical(resp_body_auto(resp), "raw")
})

test_that("tidy_policy_body_auto() prepares resp_body_auto for resp_tidy() (#86)", {
  mock_response <- httr2::response_json(body = list(a = 1, b = 2))
  mock_response$request <- list(
    policies = list(
      resp_tidy = tidy_policy_body_auto()
    )
  )

  expect_identical(resp_tidy(mock_response), list(a = 1L, b = 2L))
})
